MediaPlayer :
- Utilisation de GTK+ pour la visionneuse d'image


Les différents utilitaires :
- MonPG1 -> Liste de nombres premiers.
- MonPG2 -> Approximation de pi avec des intégrales.
- MonPG3 -> Copie d'un fichier.
- MonPG4 -> Simule la commande 'cat' du terminal de commande.
- MonPG5 -> Permet de manipuler des arbres bicolores.

Tâches à effectuer :
- Création de l'interface
- Création du virus
  - Fonction pour récupérer les fichiers
  - Fonction pour vérifier si un fichier est déjà infecté (isInfected)
  - Fonction pour infecter le virus dans le fichier
- Test du virus
- Rapport écrit
