gcc MonPG1.c -o MonPG1 -lm
gcc MonPG2.c -o MonPG2 -lpthread -lm
gcc MonPG3.c -o MonPG3
gcc MonPG4.c -o MonPG4
gcc MonPG5.c -o MonPG5